package vn.com.daisy.user;

import javax.faces.bean.ManagedBean;

@ManagedBean(name="changeStatusUser")
public class ChangeStatusUser {
	

}
