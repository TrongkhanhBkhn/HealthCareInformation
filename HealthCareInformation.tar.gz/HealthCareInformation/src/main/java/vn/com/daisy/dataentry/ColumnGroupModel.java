package vn.com.daisy.dataentry;

public class ColumnGroupModel {
	String size;
	String name;
	public ColumnGroupModel(String size, String name) {
		super();
		this.size = size;
		this.name = name;
	}
	public String getSize() {
		return size;
	}
	public void setSize(String size) {
		this.size = size;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	
}
